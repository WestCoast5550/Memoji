function myFunction(id) {
  document.getElementById(id).classList.toggle("rotate");
}
